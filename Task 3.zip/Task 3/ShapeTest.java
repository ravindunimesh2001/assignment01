import java.util.Scanner;

public class ShapeTest {

        public static void main(String[] args) {
            ShapeFactory shapeFactory = new ShapeFactory();
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter the shape you want to draw (Square, Circle, Triangle, Rectangle): ");
            String shapeType = scanner.nextLine();

            Shape shape = shapeFactory.getShape(shapeType);

            if (shape != null) {
                shape.draw();
            } else {
                System.out.println("Invalid shape type!");
            }

            scanner.close();
        }
    }


