public class ShapeFactory  {

        public Shape getShape(String shapeType) {
            if (shapeType == null) {
                return null;
            }
            switch (shapeType.toLowerCase()) {
                case "square":
                    return new Square();
                case "circle":
                    return new Circle();
                case "triangle":
                    return new Tringle();
                case "rectangle":
                    return new Rectangle();
                default:
                    return null;
            }
        }
    }


