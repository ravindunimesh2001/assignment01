public class Tringle implements Shape {

        @Override
        public void draw() {
            System.out.println("Drawing a Triangle:");
            System.out.println("  *  ");
            System.out.println(" * * ");
            System.out.println("*****");
        }
    }


