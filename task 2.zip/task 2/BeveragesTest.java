import java.util.Scanner;

public class BeveragesTest {


        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            // Tea
            Tea tea = new Tea();
            System.out.print("Do you want extras for tea? (yes/no): ");
            String teaResponse = scanner.nextLine();
            tea.setWantsExtras(teaResponse.equalsIgnoreCase("yes"));
            tea.finalTemplateMethod();

            System.out.println();

            // Coffee
            Coffee coffee = new Coffee();
            System.out.print("Do you want extras for coffee? (yes/no): ");
            String coffeeResponse = scanner.nextLine();
            coffee.setWantsExtras(coffeeResponse.equalsIgnoreCase("yes"));
            coffee.finalTemplateMethod();

            scanner.close();
        }
    }

